﻿Public Class ProxyConfig
    Property SetProxy As Boolean
    Property ProxyIP As String
    Property ProxyPort As String
    Property ProxyUsername As String
    Property ProxyPassword As String
End Class
