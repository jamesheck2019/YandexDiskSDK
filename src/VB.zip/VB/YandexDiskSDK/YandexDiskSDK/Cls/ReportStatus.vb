﻿Public Class ReportStatus
    Property ProgressPercentage As String
    Property BytesTransferred As String
    Property TotalBytes As String
    Property TextStatus As String
    Property Finished As Boolean
End Class
